#!/bin/bash

pip install -r requirement.txt
